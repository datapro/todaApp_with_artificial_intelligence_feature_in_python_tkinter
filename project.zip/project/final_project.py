from tkinter import *
from PIL import ImageTk, Image
import gtts as gTTS 
import speech_recognition as sr
import pyttsx3
import datetime
import wikipedia
import webbrowser
import os
import time
import subprocess
from ecapture import ecapture as ec
import wolframalpha
import json
import requests



root = Tk()
root.title("Abundance")
root.geometry("430x650+40+40")
root.configure(bg="grey")
root.resizable(False,False)



task_list = []


def abundance():
    print('Loading your AI personal assistant, abundance')
    engine=pyttsx3.init('sapi5')
    voices=engine.getProperty('voices')
    engine.setProperty('voice','voices[0].id')
    def speak(text):
        engine.say(text)
        engine.runAndWait()
    def wishMe():
        hour=datetime.datetime.now().hour
        if hour>=0 and hour<12:
            speak("Hello,Good Morning prince")
            print("Hello,Good Morning prince")
        elif hour>=12 and hour<18:
            speak("Hello,Good Afternoon prince")
            print("Hello,Good Afternoon prince")
        else:
            speak("Hello,Good Evening prince")
            print("Hello,Good Evening prince")

    def takeCommand():
        r=sr.Recognizer()
        with sr.Microphone() as source:
            print("Listening to you Prince...")
            audio=r.listen(source)

            try:
                statement=r.recognize_google(audio,language='en-in')
                print(f"user said:{statement}\n")

            except Exception as e:
                speak("Pardon me, please say that again")
                return "None"
            return statement

    speak("Loading your AI personal assistant, abundance")
    wishMe()


    if __name__=='__main__':


        while True:
            speak("Tell me how can I help you now?")
            statement = takeCommand().lower()
            if statement==0:
                continue

            if "good bye" in statement or "bye" in statement or "stop" in statement:
                speak('your personal assistant abundance is shutting down,Good bye')
                print('your personal assistant abundance is shutting down,Good bye')
                root.quit()
                break



            if 'wikipedia' in statement:
                speak('Searching Wikipedia...')
                statement =statement.replace("wikipedia", "")
                results = wikipedia.summary(statement, sentences=3)
                speak("According to Wikipedia")
                print(results)
                speak(results)

            elif 'open youtube' in statement:
                webbrowser.open_new_tab("https://www.youtube.com")
                speak("youtube is open now")
                time.sleep(5)
            
            elif 'open facebook' in statement:
                webbrowser.open_new_tab("https://www.facebook.com")
                speak("facebook is now open")
                time.sleep(5)
            
            elif 'open google' in statement:
                webbrowser.open_new_tab("https://www.google.com")
                speak("Google chrome is open now")
                time.sleep(5)

            elif 'open gmail' in statement:
                webbrowser.open_new_tab("gmail.com")
                speak("Google Mail open now")
                time.sleep(5)

            elif "weather" in statement:
                api_key="8ef61edcf1c576d65d836254e11ea420"
                base_url="https://api.openweathermap.org/data/2.5/weather?"
                speak("whats the city name")
                city_name=takeCommand()
                complete_url=base_url+"appid="+api_key+"&q="+city_name
                response = requests.get(complete_url)
                x=response.json()
                if x["cod"]!="404":
                    y=x["main"]
                    current_temperature = y["temp"]
                    current_humidiy = y["humidity"]
                    z = x["weather"]
                    weather_description = z[0]["description"]
                    speak(" Temperature in kelvin unit is " +
                        str(current_temperature) +
                        "\n humidity in percentage is " +
                        str(current_humidiy) +
                        "\n description  " +
                        str(weather_description))
                    print(" Temperature in kelvin unit = " +
                        str(current_temperature) +
                        "\n humidity (in percentage) = " +
                        str(current_humidiy) +
                        "\n description = " +
                        str(weather_description))

                else:
                    speak(" City Not Found ")



            elif 'time' in statement:
                strTime=datetime.datetime.now().strftime("%H:%M:%S")
                speak(f"the time is {strTime}")

            elif 'who are you' in statement or 'what can you do' in statement:
                speak('I am Abundance, version 1 point O your persoanl assistant.' 
                    'i was developed by Prince Fidelis, as a project, at new horizons ICT center, Ado-Ekiti'
                    'I am programmed to perform minor tasks like' 
                    'opening youtube, google chrome, gmail and stackoverflow, predict time, take a photo, search wikipedia,predict weather' 
                    'in different cities , get top headline news from punch news papers Nigeria and you can ask me computational or geographical questions too!')

            elif "who made you" in statement or "who created you" in statement or "who discovered you" in statement:
                speak("I was built by Prince Fidelis")
                print("I was built by Prince Fidelis")

            elif "open stackoverflow" in statement:
                webbrowser.open_new_tab("https://stackoverflow.com/login")
                speak("Here is stackoverflow")

            elif 'news' in statement:
                news = webbrowser.open_new_tab("https://punchng.com/")
                speak('Here are some headlines from the punch Nigeria, Happy reading')
                time.sleep(6)

            elif "camera" in statement or "take a photo" in statement:
                ec.capture(0,"robo camera","img.jpg")

            elif 'search'  in statement:
                statement = statement.replace("search", "")
                speak('searching')
                webbrowser.open_new_tab(statement)
                time.sleep(5)

            elif 'ask' in statement:
                speak('I can answer to computational and geographical questions and what question do you want to ask now')
                question=takeCommand()
                app_id="R2K75H-7ELALHR35X"
                client = wolframalpha.Client('R2K75H-7ELALHR35X')
                res = client.query(question)
                answer = next(res.results).text
                speak(answer)
                print(answer)


            elif "log off" in statement or "sign out" in statement:
                speak("Ok , your pc will log off in 10 sec make sure you exit from all applications, enjoy the rest of your day")
                subprocess.call(["shutdown", "/l"])

def addTask():
    task = task_entry.get()
    task_entry.delete(0,END)
    
    
    if task:
        with open("tasklist.txt", "a") as taskfile:
            taskfile.write(f"\{task}")
            task_list.append(task)
            listbox.insert(END, task)

def deleteTask():
    global task_list
    task = str(listbox.get(ANCHOR))
    if task in task_list:
        task_list.remove(task)
        with open("tasklist.txt","w",) as taskfie:
            for task in task_list:
                taskfie.write(task + "\n")
        listbox.delete(ANCHOR)
    
    

def openTaskFile():
    try:
        global task_list
        with open("tasklist.txt", "r") as taskfile:
            tasks = taskfile.readlines()
        for task in tasks:
            if task != "\n":
                task_list.append(task)
                listbox.insert(END,task)
    except:
        file = open("tasklist.txt","w")
        file.close()
       

image_icon = PhotoImage(file="./icon.png")
root.iconphoto(False, image_icon)

#top bar
TopImage = PhotoImage(file="./midnight_blue13.png")
Label(root,image=TopImage).pack()

dockImage = PhotoImage(file="./box2.png")
Label(root,image=dockImage).place(x=0,y=28)

noteImage = PhotoImage(file="./note1.png")
Label(root,image=noteImage).place(x=380,y=20)

heading = Label(root, text= "ALL TASKS", font= 'arial 20 bold', fg="white", bg= "#16182F")
heading.place(x=130, y=20)

#main frame
main_frame = Frame(root, width=500, height=40, bg= "white")
main_frame.place(x=0,y=150)

#task
task = StringVar()
task_entry = Entry(main_frame, width=25, font= "arial 15", bd=0)
task_entry.place(x=5,y=5)
task_entry.focus()

add_button = Button(main_frame, text="ADD", font="arial 17 bold", width=6,bg="#60ACF9", fg="white", bd=0, command = addTask)
add_button.place(x=340,y=0)

#speak
btn = Button(root, text= "Speak",font="arial 17 bold", width=5, bg="#60ACF9", fg="white", command=abundance)
btn.place(x=100, y=590)

btn = Button(root, text= "Exit",font="arial 17 bold", width=5, bg="#60ACF9", fg="white", command= quit)
btn.place(x=250, y=590)


#listbox
frame1 = Frame(root,bd=1, width=700, height=280, bg="#16182F")
frame1.pack(pady=(160,0))

listbox = Listbox(frame1, font= "arial 17", width=31, height=12, bg="#16182F", fg="white", cursor="hand2",selectbackground="#16182F")
listbox.pack(side=LEFT, fill=BOTH, padx=2)

scrollbar_for_list = Scrollbar(frame1)
scrollbar_for_list.pack(side=RIGHT, fill=BOTH)

listbox.config(yscrollcommand=scrollbar_for_list.set)
scrollbar_for_list.config(command=listbox.yview)

openTaskFile()

delete_icon = PhotoImage(file="./red-delete-button-png-1.png")
Button(root, image = delete_icon, bd=0, command = deleteTask).pack(side=BOTTOM, pady= 13)



root.mainloop() 
