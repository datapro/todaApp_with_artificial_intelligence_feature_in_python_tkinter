#from gtts import gTTS
from pyaudio import PyAudio
import os
mytext = "Hi, good morning prince, how are you doing today? the weather seems very nice but a little chilly, what can i do for you this morning? would you like me to read your tasks to you?!"
audio = PyAudio(text=mytext, lang="en", slow=False)
audio.save("example.mp3")
os.system("start example.mp3")