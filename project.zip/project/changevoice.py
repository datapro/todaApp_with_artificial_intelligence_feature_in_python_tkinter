import pyttsx3
converter = pyttsx3.init()
converter.setProperty('rate', 200) 
converter.setProperty('volume', 0.7)
converter.say("Hello Prince, how are you doing today?") 
converter.say("Your tasks are all set. Would you want me to read them to you?")
converter.runAndWait()



