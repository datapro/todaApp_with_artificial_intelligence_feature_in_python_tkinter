import tkinter
from tkinter import *
from PIL import ImageTk, Image
import gtts as gTTS 



root = Tk()
root.title(" My To Do List")
root.geometry("430x650")
root.configure(bg="grey")
root.resizable(False,False)

task_list = []

def addTask():
    task = task_entry.get()
    task_entry.delete(0,END)
    
    
    if task:
        with open("tasklist.txt", "a") as taskfile:
            taskfile.write(f"\{task}")
            task_list.append(task)
            listbox.insert(END, task)

def deleteTask():
    global task_list
    task = str(listbox.get(ANCHOR))
    if task in task_list:
        task_list.remove(task)
        with open("tasklist.txt","w",) as taskfie:
            for task in task_list:
                taskfie.write(task + "\n")
        listbox.delete(ANCHOR)
    
    

def openTaskFile():
    try:
        global task_list
        with open("tasklist.txt", "r") as taskfile:
            tasks = taskfile.readlines()
        for task in tasks:
            if task != "\n":
                task_list.append(task)
                listbox.insert(END,task)
    except:
        file = open("tasklist.txt","w")
        file.close()

image_icon = PhotoImage(file="./icon.png")
root.iconphoto(False, image_icon)

#top bar
TopImage = PhotoImage(file="./midnight_blue13.png")
Label(root,image=TopImage).pack()

dockImage = PhotoImage(file="./box2.png")
Label(root,image=dockImage).place(x=0,y=28)

noteImage = PhotoImage(file="./note1.png")
Label(root,image=noteImage).place(x=380,y=20)

heading = Label(root, text= "ALL TASKS", font= 'arial 20 bold', fg="white", bg= "#16182F")
heading.place(x=130, y=20)

#main frame
main_frame = Frame(root, width=500, height=40, bg= "white")
main_frame.place(x=0,y=150)

#task
task = StringVar()
task_entry = Entry(main_frame, width=25, font= "arial 15", bd=0)
task_entry.place(x=5,y=5)
task_entry.focus()

add_button = Button(main_frame, text="ADD", font="arial 17 bold", width=6,bg="#60ACF9", fg="white", bd=0, command = addTask)
add_button.place(x=340,y=0)

#listbox
frame1 = Frame(root,bd=1, width=700, height=280, bg="#16182F")
frame1.pack(pady=(160,0))

listbox = Listbox(frame1, font= "arial 17", width=31, height=12, bg="#16182F", fg="white", cursor="hand2",selectbackground="#16182F")
listbox.pack(side=LEFT, fill=BOTH, padx=2)

scrollbar_for_list = Scrollbar(frame1)
scrollbar_for_list.pack(side=RIGHT, fill=BOTH)

listbox.config(yscrollcommand=scrollbar_for_list.set)
scrollbar_for_list.config(command=listbox.yview)

openTaskFile()

delete_icon = PhotoImage(file="./red-delete-button-png-1.png")
Button(root, image = delete_icon, bd=0, command = deleteTask).pack(side=BOTTOM, pady= 13)



#spath="./ade_2.jpeg"
#simg=ImageTk.PhotoImage(Image.open(spath))
#my=Label(root,image=simg)
#my.image=simg
#my.place(x=0,y=0)


#ts = Label(root, text='All Tasks',bg="black", fg='white', width=10, height=2, font='helvetica 23')
#ts.place(x=120,y=2)





root.mainloop() 